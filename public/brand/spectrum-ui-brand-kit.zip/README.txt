Spectrum UI brand assets
========================

Logo mark and wordmark, each in dark (for light backgrounds) and light
(for dark backgrounds), as SVG and transparent PNG, plus press-quality
product screenshots (spectrum-ui-screenshot-*.png, light and dark).

Please keep the mark's shape, proportions, and colors as shipped — don't
redraw, recolor, or add effects.

Website  https://ui.spectrumhq.in
Brand    https://ui.spectrumhq.in/brandkit
GitHub   https://github.com/arihantcodes/spectrum-ui
X        https://x.com/arihantcodes
